#include "Strategy.h"

Strategy::Strategy (Player* p)
    : p_(p) {
}
